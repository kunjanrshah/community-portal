package com.krs.mvvmsampleapp.ui.auth

import android.view.View
import androidx.lifecycle.ViewModel
import com.krs.mvvmsampleapp.data.repositories.UserRepository

class AuthViewModel :ViewModel() {

    var email:String?=null
    var password:String?=null
    var authListener:AuthListener?=null

    fun onLoginButtonClick(view: View){
        authListener?.onStarted()
        if(email.isNullOrBlank() || password.isNullOrBlank()) {
            authListener?.onFailure("Invalid Password")

            return
        }

        val loginresponse=UserRepository().userLogin(email!!,password!!)
        authListener?.onSuccess(loginresponse)

    }

}