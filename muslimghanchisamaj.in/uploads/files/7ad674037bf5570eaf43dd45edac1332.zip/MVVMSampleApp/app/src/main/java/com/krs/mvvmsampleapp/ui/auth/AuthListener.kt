package com.krs.mvvmsampleapp.ui.auth

import androidx.lifecycle.LiveData

interface AuthListener {

    fun onStarted()
    fun onSuccess(loginresponse: LiveData<String>)
    fun onFailure(message:String)

}