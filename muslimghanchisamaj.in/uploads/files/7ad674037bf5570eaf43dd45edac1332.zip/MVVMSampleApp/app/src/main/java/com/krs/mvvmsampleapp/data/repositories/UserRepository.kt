package com.krs.mvvmsampleapp.data.repositories

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.krs.mvvmsampleapp.data.network.MyApi
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class UserRepository{

    fun userLogin(email:String,password:String):LiveData<String>{

     val loginresonse = MutableLiveData<String>()

     MyApi().userlogin(email, password)
         .enqueue(object :Callback<ResponseBody>{
             override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                    loginresonse.value=t.message
             }

             override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>) {
                if(response.isSuccessful){
                    loginresonse.value=response.body().toString()
                }else{
                    loginresonse.value=response.errorBody().toString()
                }
             }
         })

        return loginresonse
    }

}