package com.krs.mvvmsampleapp.ui.auth

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.LiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.krs.mvvmsampleapp.R
import com.krs.mvvmsampleapp.databinding.ActivityLoginBinding
import com.krs.mvvmsampleapp.util.hide
import com.krs.mvvmsampleapp.util.show
import com.krs.mvvmsampleapp.util.toast
import kotlinx.android.synthetic.main.activity_login.*

class LoginActivity : AppCompatActivity(),AuthListener {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setContentView(R.layout.activity_login)
        val binding:ActivityLoginBinding=DataBindingUtil.setContentView(this,R.layout.activity_login)
        val viewmodel=ViewModelProviders.of(this).get(AuthViewModel::class.java);
        binding.viewmodel=viewmodel

        viewmodel.authListener=this
    }

    override fun onStarted() {
        progress_bar.show()
    }

    override fun onSuccess(loginresponse: LiveData<String>) {

        loginresponse.observe(this, Observer {
            progress_bar.hide()
            toast(it)
        })
    }

    override fun onFailure(message: String) {
        progress_bar.hide()
        toast(message)
    }
}
